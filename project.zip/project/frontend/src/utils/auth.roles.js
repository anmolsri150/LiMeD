export const UserRole = {
  Admin: 0,
  Editor: 1
};
