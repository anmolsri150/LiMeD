const follow = [
  {
    name: 'Mayra Sibley',
    status: 'Working hard!',
    thumb: '/assets/img/profiles/l-5.jpg',
    large: '/assets/img/profiles/5.jpg',
    key: 1
  },
  {
    name: 'Philip Nelms',
    status: 'Lead Developer',
    thumb: '/assets/img/profiles/l-2.jpg',
    large: '/assets/img/profiles/2.jpg',
    key: 2
  },
  {
    name: 'Kathryn Mengel',
    status: 'Dog & Cat Person',
    thumb: '/assets/img/profiles/l-10.jpg',
    large: '/assets/img/profiles/10.jpg',
    key: 3
  },
  {
    name: 'Esperanza Lodge',
    status: 'Now giving divorce advices :)',
    thumb: '/assets/img/profiles/l-4.jpg',
    large: '/assets/img/profiles/4.jpg',
    key: 4
  },
  {
    name: 'Ken Ballweg',
    status: 'Hi there, I am using Gogo!',
    thumb: '/assets/img/profiles/l-3.jpg',
    large: '/assets/img/profiles/3.jpg',
    key: 5
  },
  {
    name: 'Rasheeda Vaquera',
    status: '...',
    thumb: '/assets/img/profiles/l-6.jpg',
    large: '/assets/img/profiles/6.jpg',
    key: 6
  },
  {
    name: 'Linn Ronning',
    status: 'What goes around comes around',
    thumb: '/assets/img/profiles/l-7.jpg',
    large: '/assets/img/profiles/7.jpg',
    key: 7
  },
  {
    name: 'Marty Otte',
    status: 'Big city life',
    thumb: '/assets/img/profiles/l-9.jpg',
    large: '/assets/img/profiles/9.jpg',
    key: 8
  },
  {
    name: 'Laree Munsch',
    status: 'New Job  :)',
    thumb: '/assets/img/profiles/l-11.jpg',
    large: '/assets/img/profiles/11.jpg',
    key: 9
  }
]

export default follow
