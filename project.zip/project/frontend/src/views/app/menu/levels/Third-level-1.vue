<template>
<div>
    <b-row>
        <b-colxx xxs="12">
            <piaf-breadcrumb :heading="$t('menu.third-level-1')" />
            <div class="separator mb-5"></div>
        </b-colxx>
    </b-row>
    <b-row>
        <b-colxx xxs="12">
            <p>{{$t('menu.third-level-1')}}</p>
        </b-colxx>
    </b-row>
</div>
</template>
